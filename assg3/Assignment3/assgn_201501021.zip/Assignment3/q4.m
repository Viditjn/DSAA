for i = 1:10
    [re a(1,i) a(2,i)] = checkC(i);
end